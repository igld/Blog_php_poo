<?php
namespace App\Table;



class Article {
    
    /**
     * __get
     *
     * @param  String $key renvoie de nom de la fonction qui correspond à la variable reçue non reconnue.
     *                 donc soit getUrl() ou getExtrait()
     *
     * @return 
     */
    public function __get($key){
        $method ='get' .ucfirst($key);
        $this->$key = $this->$method();
        return $this->$key;
    } 

    /**
     * getUrl
     *
     * @return String URL de la page de l'article complet
     */
    public function getUrl(){
        return 'index.php?p=article&id=' .$this->id;
    }

    /**
     * getExtrait
     *
     * @return String html avec un extrait de l'article 
     */
    public function getExtrait(){
        $html = '<p>' . substr($this->contenu,0, 100) . '...</p>';
        $html .= '<p><a href="' .$this->getURL() .'">Voir la suite</a></p>'; 
        return $html;
    }
}